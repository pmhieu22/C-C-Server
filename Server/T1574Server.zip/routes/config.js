// =================================================== \\
// ================MYSQL/SOCKET CONFIG================ \\
// =================================================== \\
// config_mysql_host 		= "localhost";
// config_mysql_user 		= "root";
// config_mysql_pswd 		= "password@A123";
// config_mysql_db 		  = "noderatio";
// config_ip_server      = "128.199.232.63";
// config_port_server    = 8080;

// config_mysql_host 		= "localhost";
// config_mysql_user 		= "root";
// config_mysql_pswd 		= "Vkm@1234";
// config_mysql_db 		  = "noderatio";
// config_ip_server      = "159.223.60.213";
// config_port_server    = 8080;
// config_mysql_host 		= "db";
// config_mysql_user 		= "root";
// config_mysql_pswd 		= "Vkm#1234";
// config_mysql_db 		  = "noderatio";
// config_ip_server      = "0.0.0.0";
// config_port_server    = 8080;
config_mysql_host 		= "192.168.1.91";
config_mysql_user 		= "jonny";
config_mysql_pswd 		= "vkm@1234";
config_mysql_db 		  = "noderatio";
config_ip_server      = "0.0.0.0";
config_port_server    = 8080;